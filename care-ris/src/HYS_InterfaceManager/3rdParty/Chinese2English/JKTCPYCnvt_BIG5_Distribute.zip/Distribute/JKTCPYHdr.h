#ifndef __JACKY_TANG_20051209_TCPYCNVT_HEADER__
#define __JACKY_TANG_20051209_TCPYCNVT_HEADER__

#define JKTCPYCNVT_NOBLANK			0x0001
#define JKTCPYCNVT_NOUPPERCAPITAL	0x0002
#define JKTCPYCNVT_ALLUPPER			0x0004
#define JKTCPYCNVT_DASHLINK			0x0008

#ifdef JKTCPYCNVT_EXPORT
	#define JKTCPYCNVT_API __declspec(dllexport)
#else
	#define JKTCPYCNVT_API __declspec(dllimport)
#endif

extern "C"
{
	BOOL JKTCPYCNVT_API GetTCPinyin(LPCTSTR lpszSource, LPTSTR lpszDest, DWORD dwDestSize, DWORD dwFlags);
}

#endif //__JACKY_TANG_20051209_TCPYCNVT_HEADER__
