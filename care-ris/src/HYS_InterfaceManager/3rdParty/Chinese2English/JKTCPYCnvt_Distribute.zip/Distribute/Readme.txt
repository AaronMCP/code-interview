Guide Of Traditional Chinese Pinyin Translation Utility DLL (Version 1.0)

1. System Requiement

Windows 9x/2000/NT4.0/XP
Visual C++ 6.0 or later

2. Usage

1. Include the header file "JKTCPYHdr.h" in your project, and also link the import library file "JKTCPYCnvt.lib" as following:

//include the header file
#include "JKTCPYHdr.h"
.
.
.
//link the import library file
#pragma comment(lib, "JKTCPYCnvt.lib")

2. The prototype of the exported function:

BOOL GetTCPinyin(LPCTSTR lpszSource, LPTSTR lpszDest, DWORD dwDestSize, DWORD dwFlags)

1). lpszSource	The Traditional Chinese string to be translated. (input)
2). lpszDest	The translated Pinyin string output buffer. (output)
3). dwDestSize	The size of the output buffer. (input)
4). dwFlags	The option of the translation process, detailed description as following:

	#define JKTCPYCNVT_NOBLANK			0x0001	//don't insert blanks between the translated Pinyin
	#define JKTCPYCNVT_NOUPPERCAPITAL		0x0002	//all translated Pinyin characters are in lower case
	#define JKTCPYCNVT_ALLUPPER			0x0004	//all translated Pinyin characters are in upper case
	#define JKTCPYCNVT_DASHLINK			0x0008	//insert the dash characters instead of blanks beteween the translated Pinyin

	if you have set dwFlags to 0, it means that the function will do the translation work by default action, in default case, the function will work as following:

	char szOutputBuf[256];
	GetTCPinyin("���W��", szOutputBuf, 256, 0);

	after the translation process, szOutputBuf will contain the result as "Jhang Siao Iou".


Prepared by Jacky Tang

2005.12.12

